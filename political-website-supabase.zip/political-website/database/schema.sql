-- Political Website CMS for Supabase
-- Run this whole file in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  image_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  event_date timestamptz not null,
  location text,
  image_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.gallery (
  id uuid primary key default gen_random_uuid(),
  title text,
  image_url text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  video_url text not null,
  created_at timestamptz not null default now()
);

alter table public.news enable row level security;
alter table public.events enable row level security;
alter table public.gallery enable row level security;
alter table public.videos enable row level security;

-- Public read policies
create policy "public can read news" on public.news for select to anon, authenticated using (true);
create policy "public can read events" on public.events for select to anon, authenticated using (true);
create policy "public can read gallery" on public.gallery for select to anon, authenticated using (true);
create policy "public can read videos" on public.videos for select to anon, authenticated using (true);

-- Admin authorization uses Auth app_metadata, which users cannot edit from the browser.
-- Set {"role":"admin"} in the Supabase Auth user's app_metadata.

create policy "admins insert news" on public.news for insert to authenticated
with check ((select auth.jwt()->'app_metadata'->>'role') = 'admin');
create policy "admins update news" on public.news for update to authenticated
using ((select auth.jwt()->'app_metadata'->>'role') = 'admin')
with check ((select auth.jwt()->'app_metadata'->>'role') = 'admin');
create policy "admins delete news" on public.news for delete to authenticated
using ((select auth.jwt()->'app_metadata'->>'role') = 'admin');

create policy "admins insert events" on public.events for insert to authenticated
with check ((select auth.jwt()->'app_metadata'->>'role') = 'admin');
create policy "admins update events" on public.events for update to authenticated
using ((select auth.jwt()->'app_metadata'->>'role') = 'admin')
with check ((select auth.jwt()->'app_metadata'->>'role') = 'admin');
create policy "admins delete events" on public.events for delete to authenticated
using ((select auth.jwt()->'app_metadata'->>'role') = 'admin');

create policy "admins insert gallery" on public.gallery for insert to authenticated
with check ((select auth.jwt()->'app_metadata'->>'role') = 'admin');
create policy "admins update gallery" on public.gallery for update to authenticated
using ((select auth.jwt()->'app_metadata'->>'role') = 'admin')
with check ((select auth.jwt()->'app_metadata'->>'role') = 'admin');
create policy "admins delete gallery" on public.gallery for delete to authenticated
using ((select auth.jwt()->'app_metadata'->>'role') = 'admin');

create policy "admins insert videos" on public.videos for insert to authenticated
with check ((select auth.jwt()->'app_metadata'->>'role') = 'admin');
create policy "admins update videos" on public.videos for update to authenticated
using ((select auth.jwt()->'app_metadata'->>'role') = 'admin')
with check ((select auth.jwt()->'app_metadata'->>'role') = 'admin');
create policy "admins delete videos" on public.videos for delete to authenticated
using ((select auth.jwt()->'app_metadata'->>'role') = 'admin');

-- Storage buckets for public website media.
insert into storage.buckets (id, name, public)
values ('images','images',true)
on conflict (id) do update set public = excluded.public;

insert into storage.buckets (id, name, public)
values ('videos','videos',true)
on conflict (id) do update set public = excluded.public;

-- Public read access for files in these public buckets.
create policy "public can read website images"
on storage.objects for select to anon, authenticated
using (bucket_id = 'images');

create policy "public can read website videos"
on storage.objects for select to anon, authenticated
using (bucket_id = 'videos');

-- Admin uploads/deletes only.
create policy "admins upload website images"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'images'
  and (select auth.jwt()->'app_metadata'->>'role') = 'admin'
);

create policy "admins delete website images"
on storage.objects for delete to authenticated
using (
  bucket_id = 'images'
  and (select auth.jwt()->'app_metadata'->>'role') = 'admin'
);

create policy "admins upload website videos"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'videos'
  and (select auth.jwt()->'app_metadata'->>'role') = 'admin'
);

create policy "admins delete website videos"
on storage.objects for delete to authenticated
using (
  bucket_id = 'videos'
  and (select auth.jwt()->'app_metadata'->>'role') = 'admin'
);

-- Least-privilege Data API grants.
grant select on public.news, public.events, public.gallery, public.videos to anon;
grant select, insert, update, delete on public.news, public.events, public.gallery, public.videos to authenticated;
