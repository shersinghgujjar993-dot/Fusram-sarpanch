const msg = document.getElementById("adminMsg");
const $ = id => document.getElementById(id);
let sessionUser = null;

async function requireAdmin() {
  const { data } = await supabase.auth.getSession();
  const user = data.session?.user;
  if (!user || user.app_metadata?.role !== "admin") {
    location.href = "login.html"; return false;
  }
  sessionUser = user;
  $("userEmail").textContent = user.email || "";
  return true;
}

async function upload(bucket, file) {
  if (!file) return null;
  const ext = file.name.split(".").pop().toLowerCase();
  const path = `${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, {contentType:file.type, upsert:false});
  if (error) throw error;
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
}

async function addNews(e) {
  e.preventDefault();
  try {
    const image = await upload("images", $("newsImage").files[0]);
    const { error } = await supabase.from("news").insert({title:$("newsTitle").value.trim(), description:$("newsDesc").value.trim(), image_url:image});
    if (error) throw error; e.target.reset(); msg.textContent = "News published."; loadAdminLists();
  } catch(err) { msg.textContent = err.message; }
}

async function addEvent(e) {
  e.preventDefault();
  try {
    const image = await upload("images", $("eventImage").files[0]);
    const { error } = await supabase.from("events").insert({title:$("eventTitle").value.trim(), description:$("eventDesc").value.trim(), event_date:new Date($("eventDate").value).toISOString(), location:$("eventLocation").value.trim(), image_url:image});
    if (error) throw error; e.target.reset(); msg.textContent = "Event added."; loadAdminLists();
  } catch(err) { msg.textContent = err.message; }
}

async function addGallery(e) {
  e.preventDefault();
  try {
    const image = await upload("images", $("galleryImage").files[0]);
    const { error } = await supabase.from("gallery").insert({title:$("galleryTitle").value.trim(), image_url:image});
    if (error) throw error; e.target.reset(); msg.textContent = "Photo uploaded."; loadAdminLists();
  } catch(err) { msg.textContent = err.message; }
}

async function addVideo(e) {
  e.preventDefault();
  const { error } = await supabase.from("videos").insert({title:$("videoTitle").value.trim(), video_url:$("videoUrl").value.trim()});
  if (error) msg.textContent = error.message;
  else { e.target.reset(); msg.textContent = "Video added."; loadAdminLists(); }
}

async function removeRow(table, id) {
  if (!confirm("Delete this item?")) return;
  const { error } = await supabase.from(table).delete().eq("id", id);
  if (error) msg.textContent = error.message; else loadAdminLists();
}

async function loadAdminLists() {
  const [n,e,g,v] = await Promise.all([
    supabase.from("news").select("id,title,created_at").order("created_at",{ascending:false}),
    supabase.from("events").select("id,title,event_date").order("event_date",{ascending:true}),
    supabase.from("gallery").select("id,title,created_at").order("created_at",{ascending:false}),
    supabase.from("videos").select("id,title,created_at").order("created_at",{ascending:false})
  ]);
  $("newsCount").textContent = n.data?.length || 0; $("eventCount").textContent = e.data?.length || 0; $("galleryCount").textContent = g.data?.length || 0; $("videoCount").textContent = v.data?.length || 0;
  $("newsList").innerHTML = (n.data||[]).map(x=>`<div class="row"><span>${esc(x.title)}</span><button onclick="removeRow('news','${x.id}')">Delete</button></div>`).join("");
  $("eventList").innerHTML = (e.data||[]).map(x=>`<div class="row"><span>${esc(x.title)}</span><button onclick="removeRow('events','${x.id}')">Delete</button></div>`).join("");
  $("galleryList").innerHTML = (g.data||[]).map(x=>`<div class="row"><span>${esc(x.title||"Photo")}</span><button onclick="removeRow('gallery','${x.id}')">Delete</button></div>`).join("");
  $("videoList").innerHTML = (v.data||[]).map(x=>`<div class="row"><span>${esc(x.title)}</span><button onclick="removeRow('videos','${x.id}')">Delete</button></div>`).join("");
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}

(async()=>{
  if (!await requireAdmin()) return;
  $("newsForm").addEventListener("submit", addNews);
  $("eventForm").addEventListener("submit", addEvent);
  $("galleryForm").addEventListener("submit", addGallery);
  $("videoForm").addEventListener("submit", addVideo);
  $("logout").onclick = async()=>{await supabase.auth.signOut(); location.href="login.html";};
  loadAdminLists();
})();
