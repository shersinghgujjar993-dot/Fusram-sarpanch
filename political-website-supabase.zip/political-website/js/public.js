function esc(v) {
  return String(v ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

async function loadNews(targetId = "newsGrid") {
  const el = document.getElementById(targetId); if (!el) return;
  const { data, error } = await supabase.from("news").select("*").order("created_at", {ascending:false});
  if (error) { el.innerHTML = `<p>${esc(error.message)}</p>`; return; }
  el.innerHTML = data?.length ? data.map(n => `<article class="card">${n.image_url ? `<img src="${esc(n.image_url)}" alt="">` : ""}<div class="card-body"><small>${new Date(n.created_at).toLocaleDateString("hi-IN")}</small><h3>${esc(n.title)}</h3><p>${esc(n.description)}</p></div></article>`).join("") : "<p>अभी कोई समाचार उपलब्ध नहीं है।</p>";
}

async function loadEvents() {
  const el = document.getElementById("eventsGrid"); if (!el) return;
  const { data } = await supabase.from("events").select("*").order("event_date", {ascending:true});
  el.innerHTML = (data || []).map(e => `<article class="card">${e.image_url ? `<img src="${esc(e.image_url)}" alt="">` : ""}<div class="card-body"><small>${new Date(e.event_date).toLocaleString("hi-IN")}</small><h3>${esc(e.title)}</h3><p>${esc(e.description)}</p><b>${esc(e.location)}</b></div></article>`).join("") || "<p>कोई आगामी कार्यक्रम नहीं।</p>";
}

async function loadGallery() {
  const el = document.getElementById("galleryGrid"); if (!el) return;
  const { data } = await supabase.from("gallery").select("*").order("created_at", {ascending:false});
  el.innerHTML = (data || []).map(g => `<figure><img src="${esc(g.image_url)}" alt="${esc(g.title)}"><figcaption>${esc(g.title)}</figcaption></figure>`).join("") || "<p>कोई फोटो नहीं।</p>";
}

async function loadVideos() {
  const el = document.getElementById("videosGrid"); if (!el) return;
  const { data } = await supabase.from("videos").select("*").order("created_at", {ascending:false});
  el.innerHTML = (data || []).map(v => `<article class="card video-card"><div class="video-wrap"><iframe src="${esc(toEmbed(v.video_url))}" title="${esc(v.title)}" loading="lazy" allowfullscreen></iframe></div><div class="card-body"><h3>${esc(v.title)}</h3></div></article>`).join("") || "<p>कोई वीडियो नहीं।</p>";
}

function toEmbed(url) {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtube.com")) {
      if (u.pathname === "/watch") return `https://www.youtube.com/embed/${u.searchParams.get("v")}`;
      if (u.pathname.startsWith("/shorts/")) return `https://www.youtube.com/embed/${u.pathname.split("/")[2]}`;
      if (u.pathname.startsWith("/embed/")) return url;
    }
    if (u.hostname === "youtu.be") return `https://www.youtube.com/embed/${u.pathname.slice(1)}`;
  } catch {}
  return url;
}

loadNews(); loadEvents(); loadGallery(); loadVideos();
