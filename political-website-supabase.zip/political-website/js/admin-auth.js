const form = document.getElementById("loginForm");
const msg = document.getElementById("loginMsg");

form?.addEventListener("submit", async (e) => {
  e.preventDefault();
  msg.textContent = "Logging in...";
  const { data, error } = await supabase.auth.signInWithPassword({
    email: document.getElementById("email").value.trim(),
    password: document.getElementById("password").value
  });
  if (error) { msg.textContent = error.message; return; }

  const role = data.user?.app_metadata?.role;
  if (role !== "admin") {
    await supabase.auth.signOut();
    msg.textContent = "इस account को admin access नहीं मिला है।";
    return;
  }
  location.href = "dashboard.html";
});
