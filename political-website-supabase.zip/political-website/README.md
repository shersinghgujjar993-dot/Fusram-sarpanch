# Political Website + Supabase Admin CMS

A deploy-ready static HTML/CSS/JS political website with:
- Supabase Auth admin login
- News, events, gallery and videos
- Supabase Postgres database
- Supabase Storage for images/videos
- RLS policies
- Mobile-friendly public site and admin dashboard

## 1. Create the Supabase project
Create a Supabase project, open SQL Editor, and run `database/schema.sql`.

## 2. Configure Auth
Create your first admin user in Supabase Authentication > Users.
Then give that user the `admin` role in Auth user app_metadata:
```json
{"role":"admin"}
```
Do NOT put the admin role in user metadata. The app checks `app_metadata`.

## 3. Configure the frontend
Edit `js/config.js`:
- SUPABASE_URL = your project URL
- SUPABASE_PUBLISHABLE_KEY = your publishable key

Never put a service_role/secret key in browser code.

## 4. Run locally
Because this is a static site, use any static server, e.g. VS Code Live Server, Netlify, Vercel, or:
```bash
python -m http.server 5500
```
Then open http://localhost:5500/public/

## 5. Admin
Open `/admin/login.html`, sign in with the Supabase Auth user.

## 6. Deploy
Upload the project to Vercel, Netlify, GitHub Pages (if your setup supports the required routing), or any static host.
